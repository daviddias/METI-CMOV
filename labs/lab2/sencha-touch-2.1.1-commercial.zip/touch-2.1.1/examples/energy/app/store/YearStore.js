Ext.define("EnergyApp.store.YearStore", {
    extend: "Ext.data.Store",
    alias: 'store.YearStore',
    config: {
        fields: ['type', 'data']
    }
});