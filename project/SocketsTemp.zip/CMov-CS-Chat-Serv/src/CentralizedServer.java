import java.util.ArrayList;
import java.util.Scanner;


public class CentralizedServer extends Thread {

	public static void main(String[] args) {

		ArrayList<ConnectionHandler> connections = new ArrayList<ConnectionHandler>();
		ConnectionInicializer mServer = new ConnectionInicializer(connections);
		mServer.start();


		Scanner input =  new Scanner(System.in);

		while(true){
			System.out.print("-> ");
			String msg = input.next();
			System.out.println("Sending: "+ msg);
			mServer.sendMessage(msg);

		}


	}


}