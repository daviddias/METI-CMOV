package com.example.cmov_cs_chat;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import android.util.Log;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;


public class MainActivity extends Activity {
	
	static SocketNegotiator sockNegotiator;
	static PersistentConnection conn;
	
	private Button sendButton;
	private EditText sendTextBox;
	static EditText receveTextBox;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		sendButton = (Button) findViewById(R.id.sendButton);
		sendTextBox = (EditText) findViewById(R.id.sendEditText);
		receveTextBox = (EditText) findViewById(R.id.receveEditText);
		
		receveTextBox.setText("#Calling Home..."+"\n");
		new EstablishConnectionTask().execute("");
		
		
		sendButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
		//		mTcpClient.sendMessage(sendTextBox.getText().toString());
		//		sendTextBox.setText(null);
			}
		});
	}

	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}








class EstablishConnectionTask extends AsyncTask<String,String,Void> {
	
	private	final String SERVER_IP = "10.0.2.2";
	private	final int SERVER_PORT = 4444;
	private Integer remotePort;
	

	@Override
	protected Void doInBackground(String... message) {

		//Cria objecto que trata da negociação da porta e define a função de callback
		MainActivity.sockNegotiator = new SocketNegotiator(new SocketNegotiator.OnMessageReceived() {
			@Override
			public void updateMessage(String message) {
				publishProgress(message);
			}
		});
		remotePort = MainActivity.sockNegotiator.getPort(SERVER_IP, SERVER_PORT);
		Log.e("Port", remotePort.toString());



		//Começa uma comunicçao persistente com o servidor
		MainActivity.conn = new PersistentConnection(new PersistentConnection.OnMessageReceived() {
			@Override
			public void messageReceived(String message) {
				publishProgress(message);
			}
		});
		MainActivity.conn.startChat(SERVER_IP, remotePort);
		
		return null;
	}

    @Override
    protected void onProgressUpdate(String... values) {
    	super.onProgressUpdate(values);
    	MainActivity.receveTextBox.append(values[0].toString() + "\n");
    }

    	
//		//we create a TCPClient object and add the interface
//		MainActivity.mTcpClient = new TCPClient(new TCPClient.OnMessageReceived() {			
//			@Override
//			public void messageReceived(String message) {
//				//this method calls the onProgressUpdate
//				publishProgress(message);
//			}
//		});
		
//		MainActivity.mTcpClient.run();
//		return null;
//    }

//    @Override
//    protected void onProgressUpdate(String... values) {
//        super.onProgressUpdate(values);
//
//        //in the arrayList we add the messaged received from server
//        //arrayList.add(values[0]);
//        
//        MainActivity.receveTextBox.append(values[0]);
//    }
//    
    
}

















