package com.example.cmov_cs_chat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;

import android.util.Log;

public class PersistentConnection{

    private OnMessageReceived mMessageListener = null;
    private boolean mRun = false;
 
   // PrintWriter out;
    BufferedReader in;
 
    /**
     *  OnMessagedReceived listens for the messages received from server
     */
    public PersistentConnection(OnMessageReceived listener) {
        mMessageListener = listener;
    }
 
//    /**
//     * Sends the message entered by client to the server
//     * @param message text entered by client
//     */
//    public void sendMessage(String message){
//        if (out != null && !out.checkError()) {
//            out.println(message);
//            out.flush();
//        }
//    }
 
//    public void stopClient(){
//        mRun = false;
//    }
 
    public void startChat(String ServerIP, Integer remotePort) {
    	
    	mRun = true;

    	try {
    		InetAddress serverAddr = InetAddress.getByName(ServerIP);
    		Socket socket = null;
    		
    		while(true){
    			
    			Log.e("TCP Client", "C: Connecting...");
    			while(true){
    				try{
    					//create a socket to make the connection with the server
    					socket = new Socket(serverAddr, remotePort);
    					break;
    				}catch(Exception e){
    					Log.e("TCP", e.toString());
    					Log.e("TCP", "Sleeping 2000ms");
    					Thread.sleep(2000);
    				}

    			
    			}
    			try {

    				//send the message to the server
//    				out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
//    				
//    				out.write("Want Port");
//    				out.flush();
//    				out.close();
//    				Log.e("TCP", "Want Port Sent");
    				
    				
    				
    				//receive the message which the server sends back
    				in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//    				Log.e("TCP", "Test1");
//    				while(!in.ready()){
//    					Thread.sleep(100);
//    				}
    				String port = in.readLine();
    				
    				Log.e("TCP", "Receved Port : " + port);
    				
    				return;

//    				//in this while the client listens for the messages sent by the server
//    				while (mRun) {
//    					serverMessage = in.readLine();
//
//    					if (serverMessage != null && mMessageListener != null) {
//    						//call the method messageReceived from MyActivity class
//    						mMessageListener.messageReceived(serverMessage);
//    					}
//
//    					if(serverMessage == null){
//    						Log.e("TCP Client", "C: Connection Down, Retrying");
//    						break;
//    					}
//
//    					serverMessage = null;	
//
//    				}

    				//Log.e("RESPONSE FROM SERVER", "S: Received Message: '" + serverMessage + "'");


    			} catch (Exception e) {

    				Log.e("TCP", "S: Error Exception");

    			} finally {
    				//the socket must be closed. It is not possible to reconnect to this socket
    				// after it is closed, which means a new socket instance has to be created.
    				Log.e("TCP", "C: Closing Sock");
    				socket.close();
    			}

    		}


    	} catch (Exception e) {
    		
            Log.e("TCP", "C: Error Exception2"+e.toString());
 
        }
 
    }
 
    //Declare the interface. The method messageReceived(String message) will must be implemented in the MyActivity
    //class at on asynckTask doInBackground
    public interface OnMessageReceived {
        public void messageReceived(String message);
    }
}
