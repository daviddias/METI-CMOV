package com.example.cmov_cs_chat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;

import android.util.Log;

class SocketNegotiator {
	 
    private OnMessageReceived mListener = null;
    private BufferedReader in;
 
    /**
     *  OnMessagedReceived listens for the messages received from server
     */
    public SocketNegotiator(OnMessageReceived listen) {
      mListener = listen;
    }
 
    public Integer getPort(String serverIP, int serverPort) {
    	
    	try {
    		
    		InetAddress serverAddr = InetAddress.getByName(serverIP);
    		Socket socket = null;
    		
    		while(true){
    			
    			// Contacting the Server
    			while(true){
    				try{
    					socket = new Socket(serverAddr, serverPort);
    					break;
    				}catch(Exception e){
    					Log.e("TCP", "Sleeping 5s");
    					Thread.sleep(5000);
    					mListener.updateMessage("#Server Down Retrying in 5 ...");
    				}
    			}
    			
    			
    			// If Conected get new port
    			try {
    				//receive the message which the server sends back
    				in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    				String port = in.readLine();
    				
    				Log.e("TCP", "Receved Port : " + port);
    				mListener.updateMessage("#Received port "+port+" for chating");
    				mListener.updateMessage("#Server " + socket.getPort() + " " + socket.getLocalPort() + " ");
    				return Integer.parseInt(port);
    				
    			} catch (Exception e) {

    				Log.e("TCP", "S: Error Exception");

    			} finally {
    				Log.e("TCP", "C: Closing Sock");
    				socket.close();
    			}
    		}

    	} catch (Exception e) {
            Log.e("TCP", "C: Error Exception2"+e.toString());
        }
		return null;
    }
    
    
    public interface OnMessageReceived {
    	
		public void updateMessage(String message);
    }
}