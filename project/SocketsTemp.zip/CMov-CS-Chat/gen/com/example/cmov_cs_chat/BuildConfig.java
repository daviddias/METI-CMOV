/** Automatically generated file. DO NOT MODIFY */
package com.example.cmov_cs_chat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}