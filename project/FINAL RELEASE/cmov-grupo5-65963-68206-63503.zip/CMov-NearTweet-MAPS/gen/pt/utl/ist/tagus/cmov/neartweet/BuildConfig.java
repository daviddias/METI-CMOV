/** Automatically generated file. DO NOT MODIFY */
package pt.utl.ist.tagus.cmov.neartweet;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}