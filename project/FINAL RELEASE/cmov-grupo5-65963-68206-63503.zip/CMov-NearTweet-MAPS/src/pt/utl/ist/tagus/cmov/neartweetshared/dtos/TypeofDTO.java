package pt.utl.ist.tagus.cmov.neartweetshared.dtos;

public enum TypeofDTO {
	BASIC_DTO, TWEET_DTO, TWEET_RESP_DTO, IDENTITY_DTO, SPAMM_DTO, POLL_DTO, POLL_RESPONSE_DTO
}
