var searchData=
[
  ['returnsignature',['returnSignature',['../structajn_1_1_interface_description_1_1_member.html#a770faae4a4c48da9e6eedd63570a0d2c',1,'ajn::InterfaceDescription::Member']]]
];
