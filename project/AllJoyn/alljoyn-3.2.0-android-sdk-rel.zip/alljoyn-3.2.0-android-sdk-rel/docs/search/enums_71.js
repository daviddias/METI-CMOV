var searchData=
[
  ['qstatus',['QStatus',['../_status_8h.html#a5e32723579defc8552e38ce23e7b0e5d',1,'Status.h']]]
];
