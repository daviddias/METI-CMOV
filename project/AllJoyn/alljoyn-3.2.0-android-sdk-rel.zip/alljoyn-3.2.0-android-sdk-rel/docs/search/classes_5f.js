var searchData=
[
  ['_5fmessage',['_Message',['../classajn_1_1___message.html',1,'ajn']]]
];
