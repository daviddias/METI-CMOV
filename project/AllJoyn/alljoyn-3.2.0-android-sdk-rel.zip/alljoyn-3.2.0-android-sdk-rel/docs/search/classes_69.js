var searchData=
[
  ['interfacedescription',['InterfaceDescription',['../classajn_1_1_interface_description.html',1,'ajn']]]
];
