var searchData=
[
  ['iface',['iface',['../structajn_1_1_interface_description_1_1_member.html#ac9b204b5f42e7ff5227a8f0717f084c5',1,'ajn::InterfaceDescription::Member']]],
  ['interfacename',['InterfaceName',['../namespaceajn_1_1org_1_1alljoyn_1_1_bus.html#a5a9be77e6eee78af7d456a92ed08b4c4',1,'ajn::org::alljoyn::Bus::InterfaceName()'],['../namespaceajn_1_1org_1_1alljoyn_1_1_daemon.html#ae4369ccc8b5e856628c0db4edcf40ba1',1,'ajn::org::alljoyn::Daemon::InterfaceName()']]],
  ['ismultipoint',['isMultipoint',['../classajn_1_1_session_opts.html#a2f37a1243e96a1378fc7e1260ddcd4d8',1,'ajn::SessionOpts']]]
];
