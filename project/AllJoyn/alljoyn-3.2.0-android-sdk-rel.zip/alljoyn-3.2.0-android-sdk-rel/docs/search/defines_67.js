var searchData=
[
  ['generateversionvalue',['GenerateVersionValue',['../version_8h.html#a38d8f6af8e76fb3a4b82879ffc08b784',1,'version.h']]],
  ['getversionapilevel',['GetVersionAPILevel',['../version_8h.html#a4adf0f195d0095d480d44fcead62f671',1,'version.h']]],
  ['getversionarch',['GetVersionArch',['../version_8h.html#a0ad2ef27cf192628d67117ec9ff8aa9d',1,'version.h']]],
  ['getversionrelease',['GetVersionRelease',['../version_8h.html#a7c0ebf8f0ff748534226152311a1e5df',1,'version.h']]]
];
