var searchData=
[
  ['errorname',['ErrorName',['../namespaceajn_1_1org_1_1alljoyn_1_1_bus.html#a683a08af7424bc290ecd4488a5e6e4a5',1,'ajn::org::alljoyn::Bus::ErrorName()'],['../namespaceajn_1_1org_1_1alljoyn_1_1_daemon.html#ad43c305e18312e1f410373f9efcbd43a',1,'ajn::org::alljoyn::Daemon::ErrorName()']]],
  ['eventtype',['eventType',['../classajn_1_1_simple_bus_listener_1_1_bus_event.html#a077dcf8aa56ce6529a0e06200b9e8c39',1,'ajn::SimpleBusListener::BusEvent']]]
];
