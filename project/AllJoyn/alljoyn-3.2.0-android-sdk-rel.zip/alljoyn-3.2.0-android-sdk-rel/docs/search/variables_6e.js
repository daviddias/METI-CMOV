var searchData=
[
  ['name',['name',['../structajn_1_1_interface_description_1_1_member.html#a6fcb3ea34ef428d45d0ff7d81d860dc5',1,'ajn::InterfaceDescription::Member::name()'],['../structajn_1_1_interface_description_1_1_property.html#a551d5c7eb48aab76a3caa11a34c62baa',1,'ajn::InterfaceDescription::Property::name()'],['../classajn_1_1_simple_bus_listener_1_1_bus_event.html#aff753e65a4d5341203fdddbb55556518',1,'ajn::SimpleBusListener::BusEvent::name()']]],
  ['nameprefix',['namePrefix',['../classajn_1_1_simple_bus_listener_1_1_bus_event.html#a2285c0faba3c15b1d2a9199aa52609fb',1,'ajn::SimpleBusListener::BusEvent']]],
  ['newowner',['newOwner',['../classajn_1_1_simple_bus_listener_1_1_bus_event.html#a2cd2793ec2acd693e959dd6d8694319a',1,'ajn::SimpleBusListener::BusEvent']]],
  ['numelements',['numElements',['../structajn_1_1_all_joyn_scalar_array.html#a4dcdfd8d5f259daadbac39306332efe1',1,'ajn::AllJoynScalarArray']]],
  ['nummembers',['numMembers',['../structajn_1_1_all_joyn_struct.html#ab21383cf01af18e87ca8b5078b378360',1,'ajn::AllJoynStruct']]]
];
