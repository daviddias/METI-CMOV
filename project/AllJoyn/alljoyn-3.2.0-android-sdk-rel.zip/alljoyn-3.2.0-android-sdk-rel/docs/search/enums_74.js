var searchData=
[
  ['traffictype',['TrafficType',['../classajn_1_1_session_opts.html#a31c6d90868dac02c1e30c3c4c73fbc20',1,'ajn::SessionOpts']]]
];
