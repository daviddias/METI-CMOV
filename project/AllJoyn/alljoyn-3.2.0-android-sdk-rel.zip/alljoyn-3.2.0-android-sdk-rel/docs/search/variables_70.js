var searchData=
[
  ['previousowner',['previousOwner',['../classajn_1_1_simple_bus_listener_1_1_bus_event.html#a071d5fa4e3d860a489bd3393a527a3e0',1,'ajn::SimpleBusListener::BusEvent']]],
  ['prop_5faccess_5fread',['PROP_ACCESS_READ',['../namespaceajn.html#a6e8b75741c331238cb512d806fbe2957',1,'ajn']]],
  ['prop_5faccess_5frw',['PROP_ACCESS_RW',['../namespaceajn.html#a35e1f930e4008965043719c3bbc90792',1,'ajn']]],
  ['prop_5faccess_5fwrite',['PROP_ACCESS_WRITE',['../namespaceajn.html#a09445b7c25140ec3a964ecda4b81f575',1,'ajn']]]
];
