var searchData=
[
  ['wellknownname',['WellKnownName',['../namespaceajn_1_1org_1_1alljoyn_1_1_bus.html#a3dbaadb80868bab579dc3a0129abb2e8',1,'ajn::org::alljoyn::Bus::WellKnownName()'],['../namespaceajn_1_1org_1_1alljoyn_1_1_daemon.html#a0fa956270dad3d70ef09405cff100bdd',1,'ajn::org::alljoyn::Daemon::WellKnownName()']]]
];
