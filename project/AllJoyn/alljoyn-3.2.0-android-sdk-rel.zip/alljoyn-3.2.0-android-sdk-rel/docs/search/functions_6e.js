var searchData=
[
  ['namehasowner',['NameHasOwner',['../classajn_1_1_bus_attachment.html#af5f3e72d9ec455dc3fc9c1a1254a76df',1,'ajn::BusAttachment']]],
  ['nameownerchanged',['NameOwnerChanged',['../classajn_1_1_bus_listener.html#aa6481a07f302499434237903e98f2590',1,'ajn::BusListener']]]
];
