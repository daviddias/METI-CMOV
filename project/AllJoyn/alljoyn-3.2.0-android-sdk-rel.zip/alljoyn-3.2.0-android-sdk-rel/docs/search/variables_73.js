var searchData=
[
  ['secure',['Secure',['../namespaceajn_1_1org_1_1alljoyn_1_1_bus.html#a6cc88f0bd6c7b12d03e93a360c7334ac',1,'ajn::org::alljoyn::Bus']]],
  ['session_5fport_5fany',['SESSION_PORT_ANY',['../namespaceajn.html#a435c9d4843483e8e40f6ec9156ab1749',1,'ajn']]],
  ['sig',['sig',['../structajn_1_1_all_joyn_signature.html#ad1aede5230c55652cd6043612d4ceb8b',1,'ajn::AllJoynSignature']]],
  ['signature',['signature',['../structajn_1_1_interface_description_1_1_member.html#a6a0ed24a5a9e9327c787f76dc9214b35',1,'ajn::InterfaceDescription::Member::signature()'],['../structajn_1_1_interface_description_1_1_property.html#adbadead698d4c2dc86b86911abedc42c',1,'ajn::InterfaceDescription::Property::signature()']]],
  ['str',['str',['../structajn_1_1_all_joyn_string.html#a78aded59804ef9812b085dfd82f71f04',1,'ajn::AllJoynString']]]
];
