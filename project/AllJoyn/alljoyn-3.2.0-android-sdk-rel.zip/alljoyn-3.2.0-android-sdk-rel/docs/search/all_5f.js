var searchData=
[
  ['_5fmessage',['_Message',['../classajn_1_1___message.html',1,'ajn']]],
  ['_5fmessage',['_Message',['../classajn_1_1___message.html#a4bfca2b42e4e37abb3f6884c45d5a85b',1,'ajn::_Message::_Message(BusAttachment &amp;bus)'],['../classajn_1_1___message.html#a27c80a07d0e8269a9ffe5edc5fadcdcf',1,'ajn::_Message::_Message(const _Message &amp;other)']]],
  ['_5fproxybusobject',['_ProxyBusObject',['../namespaceajn.html#a3116f54742e95f183215e515def06005',1,'ajn']]]
];
