var searchData=
[
  ['handler',['handler',['../structajn_1_1_bus_object_1_1_method_entry.html#a3b16763fafe0452f7029f4b0b3c80104',1,'ajn::BusObject::MethodEntry']]]
];
