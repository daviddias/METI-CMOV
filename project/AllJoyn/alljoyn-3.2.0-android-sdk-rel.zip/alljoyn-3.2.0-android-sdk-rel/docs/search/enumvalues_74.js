var searchData=
[
  ['traffic_5fmessages',['TRAFFIC_MESSAGES',['../classajn_1_1_session_opts.html#a31c6d90868dac02c1e30c3c4c73fbc20a9183d6f2e39bdaf8c7bb5573af9c6472',1,'ajn::SessionOpts']]],
  ['traffic_5fraw_5freliable',['TRAFFIC_RAW_RELIABLE',['../classajn_1_1_session_opts.html#a31c6d90868dac02c1e30c3c4c73fbc20a862a14cd0d500cea9b807d3bfd0815a8',1,'ajn::SessionOpts']]],
  ['traffic_5fraw_5funreliable',['TRAFFIC_RAW_UNRELIABLE',['../classajn_1_1_session_opts.html#a31c6d90868dac02c1e30c3c4c73fbc20a7be2b7e6470cf5eeb0cb58d8aa541fcc',1,'ajn::SessionOpts']]]
];
